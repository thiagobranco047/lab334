# Changelog

## 0.1.3 - 2026-09-08

- Make provenance stable across commits that contain only generated artifacts.

## 0.1.2 - 2026-09-08

- Reissue the runtime catalog declarations from a clean, committed source revision.

## 0.1.1 - 2026-09-08

- Declare browser-safe runtime catalogs in the TypeScript surface.

## 0.1.0 - 2026-09-08

- Initial browser-safe access/schema types.
- Initial server-only normalized Organization and Business Unit catalogs.
- Deterministic validation, provenance, packing, and SHA-256 verification.
