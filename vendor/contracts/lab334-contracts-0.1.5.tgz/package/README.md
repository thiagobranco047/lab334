# @lab334/contracts

Generated contracts for LAB applications. Canonical sources remain in the top-level `organizations/`, `capabilities/`, and `schemas/` directories. Never edit `dist/` or an archive manually.

```powershell
npm install
npm run contracts:pack
```

The default export is browser-safe. `@lab334/contracts/server` contains normalized tenant catalogs and schemas and must only be imported by server code.

Release compatibility follows SemVer: patches preserve behavior, minors add backward-compatible fields/exports, and majors remove, rename, reinterpret, or tighten accepted contracts. To update `lab334`, copy the generated `.tgz` and `.sha256` byte-for-byte into `vendor/contracts`, run `npm install`, then `npm run contracts:verify` and the full application validation suite.

The vendored archive is temporary distribution infrastructure. A future private registry will publish the identical package surface and version; consumers will change only the dependency locator.
